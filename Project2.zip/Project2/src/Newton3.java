import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class Newton3 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton3() {
    }

    /**
     * Put a short phrase describing the static method myMethod here.
     */
    private static double sqrt(double x, double err) {
        // Define a method to calculate the square root of a number with a given error ratio

        if (x == 0) {
            // Check if the input number is 0; return NaN (Not-a-Number) in this case
            return Double.NaN;
        }
        double r = x;
        while (Math.abs(r - x / r) > err * r) {
            // Use a loop to refine the approximation until it meets the specified error ratio
            r = (x / r + r) / 2.0;
            // Update the approximation using the formula for Newton's method
        }
        // Return the calculated square root
        return r;

    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        // Prompt the user for input
        out.print("Do you wish to wish to calculate a square root? y/n \n");
        String c = in.nextLine();
        // Read the user's response
        String n = "y";

        while (c.equals(n)) {
            c = "a";
            // Reset 'c' to a default value for the loop condition
            out.print("Enter a number:");
            double x = in.nextDouble();
            // Prompt the user to enter a number
            out.print("Enter a error ratio:");
            // Prompt the user to enter an error ratio
            double err = in.nextDouble();
            double y = sqrt(x, err);
            out.print(y + "\n");
            // Calculate the square root using the 'sqrt' method and display the result
            out.print(
                    "Do you wish to wish to calculate a square root again? y/n");
            // Ask the user if they want to calculate another square root
            c = in.nextLine();
            // Read the user's response for the loop continuation
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
        return;
    }

}
