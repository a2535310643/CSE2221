import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class Newton5 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton5() {
    }

    /**
     * Put a short phrase describing the static method myMethod here.
     */
    private static double sqrt(double x, double err) {

        if (x == 0) {
            return Double.NaN;
        }
        double r = x;
        while (Math.abs(r - x / r) > err * r) {
            r = (x / r + r) / 2.0;
        }

        return r;
        /*
         * Put your code for myMethod here
         */
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.print("Do you wish to wish to calculate a square root? y/n \n");
        String c = in.nextLine();
        String n = "y";

        while (c.equals(n)) {
            c = "a";
            out.print("Enter a number:");
            double x = in.nextDouble();
            if (x < 0) {
                out.print("it's time to quit");
                break;
            }
            out.print("Enter a error ratio:");
            double err = in.nextDouble();
            double y = sqrt(x, err);
            out.print(y + "\n");
            out.print(
                    "Do you wish to wish to calculate a square root again? y/n");
            c = in.nextLine();
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
        return;
    }

}
