import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 *
 * @author Xinwei Zhang
 *
 * @mathdefinitions <pre>
 *
 */

public class StringReassembleTest {

    @Test
    public void combinationTest1() {
        String str = StringReassemble.combination("abcde", "defgh", 2);
        assertEquals("abcdefgh", str);
    }

    @Test
    public void combinationTest2() {
        String str = StringReassemble.combination("123456", "1234567890", 6);
        assertEquals("1234567890", str);
    }

    @Test
    public void addToSetAvoidingSubstringsTest1() {
        String str1 = "Forget it!";
        String str2 = "it!";
        String str3 = "Forget it! do what you want do!";

        Set<String> result = new Set1L<String>();
        Set<String> test = new Set1L<String>();

        result.add(str3);
        result.add("5");

        StringReassemble.addToSetAvoidingSubstrings(test, str1);
        StringReassemble.addToSetAvoidingSubstrings(test, str2);
        StringReassemble.addToSetAvoidingSubstrings(test, str3);
        StringReassemble.addToSetAvoidingSubstrings(test, "5");
        StringReassemble.addToSetAvoidingSubstrings(test, "F");
        assertEquals(result, test);
    }

    @Test
    public void addToSetAvoidingSubstringsTest2() {
        String str1 = "Forget it!";
        String str2 = " ";
        String str3 = "Forget it! do what you want do!";

        Set<String> result = new Set1L<String>();
        Set<String> test = new Set1L<String>();

        result.add(str3);
        result.add("5");

        StringReassemble.addToSetAvoidingSubstrings(test, str1);
        StringReassemble.addToSetAvoidingSubstrings(test, str2);
        StringReassemble.addToSetAvoidingSubstrings(test, str3);
        StringReassemble.addToSetAvoidingSubstrings(test, "5");
        StringReassemble.addToSetAvoidingSubstrings(test, "F");
        assertEquals(result, test);
    }

    @Test
    public void addToSetAvoidingSubstringsTest3() {
        String str1 = "it!";
        String str2 = "Forget";
        String str3 = "Forget it!";

        Set<String> result = new Set1L<String>();
        Set<String> test = new Set1L<String>();

        result.add(str3);
        result.add("5");

        StringReassemble.addToSetAvoidingSubstrings(test, str1);
        StringReassemble.addToSetAvoidingSubstrings(test, str2);
        StringReassemble.addToSetAvoidingSubstrings(test, str3);
        StringReassemble.addToSetAvoidingSubstrings(test, "5");
        StringReassemble.addToSetAvoidingSubstrings(test, "F");

        assertEquals(result, test);
    }

    @Test
    public void linesFromInputTest2() {
        String s = "data\\test2.txt";
        SimpleReader in = new SimpleReader1L(s);

        SimpleWriter out = new SimpleWriter1L();
        Set<String> testSet = new Set1L<String>();
        Set<String> ansSet = new Set1L<String>();

        testSet = StringReassemble.linesFromInput(in);

        String str1 = "dog";
        String str2 = "Forget it";
        String str3 = "o just do it";
        String str4 = "Beat";
        String str5 = "it";
        String str6 = "Bucks";
        String str7 = "OSU";
        ansSet.add(str1);
        ansSet.add(str2);
        ansSet.add(str3);
        ansSet.add(str4);
        ansSet.add(str7);

        assertEquals(ansSet, testSet);

    }

    @Test
    public void linesFromInputTest() {
        String s = "data\\test.txt";
        SimpleReader in = new SimpleReader1L(s);

        SimpleWriter out = new SimpleWriter1L();
        Set<String> testSet = new Set1L<String>();
        Set<String> ansSet = new Set1L<String>();

        testSet = StringReassemble.linesFromInput(in);

        String str1 = "Bucks -- Ohio";
        String str2 = "Go Bucks";
        String str3 = "Bucks -- O";
        String str4 = "Beat him";
        String str5 = "SU";
        String str6 = "Bucks";
        String str7 = "OSU";
        ansSet.add(str1);
        ansSet.add(str2);
        ansSet.add(str4);
        ansSet.add(str7);

        out.println(testSet.toString());
        out.println(ansSet.toString());

        out.close();

        assertEquals(ansSet, testSet);

    }

    @Test
    public void printWithLineSeparatorsTest() {
        String text = "dog~cat~abcdefghijk~";
        SimpleWriter out = new SimpleWriter1L(
                "printWithLineSeparatorsTest.txt");
        StringReassemble.printWithLineSeparators(text, out);
        out.close();
        SimpleReader in = new SimpleReader1L("printWithLineSeparatorsTest.txt");

        assertEquals("dog", in.nextLine());
        assertEquals("cat", in.nextLine());
        assertEquals("abcdefghijk", in.nextLine());
    }

    @Test
    public void printWithLineSeparatorsTest2() {
        String text = "dog";
        SimpleWriter out = new SimpleWriter1L(
                "printWithLineSeparatorsTest2.txt");
        StringReassemble.printWithLineSeparators(text, out);
        out.close();
        SimpleReader in = new SimpleReader1L(
                "printWithLineSeparatorsTest2.txt");

        assertEquals("dog", in.nextLine());
    }

    @Test
    public void printWithLineSeparatorsTest3() {
        String text = "~dog";
        SimpleWriter out = new SimpleWriter1L(
                "printWithLineSeparatorsTest3.txt");
        StringReassemble.printWithLineSeparators(text, out);
        out.close();
        SimpleReader in = new SimpleReader1L(
                "printWithLineSeparatorsTest3.txt");

        assertEquals("", in.nextLine());
        assertEquals("dog", in.nextLine());
    }

}
