import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Xinwei Zhang
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    @Test
    public void testReduceToGCD_0_0() {
        // Test case to verify the behavior of ReducingToGCD when both numbers are 0.
        // The expected result is that both numbers remain 0.
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_30_21() {
        // Test case to verify the behavior of ReducingToGCD with 30 and 21
        // The expected result is that n is 3 and m is 0.
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(21);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_49_63() {
        // Test case to verify the behavior of ReducingToGCD with 49 and 63
        // The expected result is that n is 7 and m is 0.
        NaturalNumber n = new NaturalNumber2(49);
        NaturalNumber nExpected = new NaturalNumber2(7);
        NaturalNumber m = new NaturalNumber2(63);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_81_9() {
        // Test case to verify the behavior of ReducingToGCD with 81 and 9
        // The expected result is that n is 9 and m is 0.
        NaturalNumber n = new NaturalNumber2(81);
        NaturalNumber nExpected = new NaturalNumber2(9);
        NaturalNumber m = new NaturalNumber2(9);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_15_2000() {
        // Test case to verify the behavior of ReducingToGCD with 15 and 2000
        // The expected result is that n is 5 and m is 0.
        NaturalNumber n = new NaturalNumber2(2000);
        NaturalNumber nExpected = new NaturalNumber2(5);
        NaturalNumber m = new NaturalNumber2(15);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * Tests of isEven
     */

    @Test
    public void testIsEven_0() {
        // Test case to verify the behavior of isEven with 0
        // The expected result is true
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsEven_1() {
        // Test case to verify the behavior of isEven with 1
        // The expected result is false
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber nExpected = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    @Test
    public void testIsEven_2() {
        // Test case to verify the behavior of isEven with 2
        // The expected result is true
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(2);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsEven_1000() {
        // Test case to verify the behavior of isEven with 1000
        // The expected result is true
        NaturalNumber n = new NaturalNumber2(1000);
        NaturalNumber nExpected = new NaturalNumber2(1000);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsEven_10001() {
        //challenging
        // Test case to verify the behavior of isEven with 10001
        // The expected result is false
        NaturalNumber n = new NaturalNumber2(10001);
        NaturalNumber nExpected = new NaturalNumber2(10001);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Tests of powerMod
     */

    @Test
    public void testPowerMod_0_0_2() {
        // Test case to verify the behavior of testPowerMod with 0 0 2
        // The expected n is 1, p is 0, m is 2
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber pExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        NaturalNumber mExpected = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_17_18_19() {
        // Test case to verify the behavior of testPowerMod with 17 18 19
        // The expected n is 1, p is 18, m is 19
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber pExpected = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        NaturalNumber mExpected = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_20_22_23() {
        // Test case to verify the behavior of testPowerMod with 20 22 23
        // The expected n is 1, p is 22, m is 23
        NaturalNumber n = new NaturalNumber2(20);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(22);
        NaturalNumber pExpected = new NaturalNumber2(22);
        NaturalNumber m = new NaturalNumber2(23);
        NaturalNumber mExpected = new NaturalNumber2(23);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_50_57_58() {
        // Test case to verify the behavior of testPowerMod with 50 57 58
        // The expected n is 50, p is 57, m is 58
        NaturalNumber n = new NaturalNumber2(50);
        NaturalNumber nExpected = new NaturalNumber2(50);
        NaturalNumber p = new NaturalNumber2(57);
        NaturalNumber pExpected = new NaturalNumber2(57);
        NaturalNumber m = new NaturalNumber2(58);
        NaturalNumber mExpected = new NaturalNumber2(58);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_50_62_65() {
        // Test case to verify the behavior of testPowerMod with 50 62 65
        // The expected n is 30, p is 62, m is 65
        NaturalNumber n = new NaturalNumber2(50);
        NaturalNumber nExpected = new NaturalNumber2(30);
        NaturalNumber p = new NaturalNumber2(62);
        NaturalNumber pExpected = new NaturalNumber2(62);
        NaturalNumber m = new NaturalNumber2(65);
        NaturalNumber mExpected = new NaturalNumber2(65);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * Test of IsPrime1
     */

    @Test
    public void testIsPrime1_2() {
        // Test case to verify the behavior of IsPrime1 with 2
        // The expected true
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(2);
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsPrime1_1000000() {
        //challenging
        // Test case to verify the behavior of IsPrime1 with 1000000
        // The expected false
        NaturalNumber n = new NaturalNumber2(100000);
        NaturalNumber nExpected = new NaturalNumber2(100000);
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    @Test
    public void testIsPrime1_599() {
        // Test case to verify the behavior of IsPrime1 with 599
        // The expected true
        NaturalNumber n = new NaturalNumber2(599);
        NaturalNumber nExpected = new NaturalNumber2(599);
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsPrime1_500() {
        // Test case to verify the behavior of IsPrime1 with 500
        // The expected false
        NaturalNumber n = new NaturalNumber2(500);
        NaturalNumber nExpected = new NaturalNumber2(500);
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Test of IsPrime2
     */

    @Test
    public void testIsPrime2_2() {
        // Test case to verify the behavior of IsPrime1 with 2
        // The expected true
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(2);
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsPrime2_1000000() {
        // Test case to verify the behavior of IsPrime1 with 10000000
        // The expected false
        NaturalNumber n = new NaturalNumber2(100000);
        NaturalNumber nExpected = new NaturalNumber2(100000);
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    @Test
    public void testIsPrime2_799() {
        // Test case to verify the behavior of IsPrime1 with 799
        // The expected true
        NaturalNumber n = new NaturalNumber2(599);
        NaturalNumber nExpected = new NaturalNumber2(599);
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsPrime2_500() {
        // Test case to verify the behavior of IsPrime1 with 500
        // The expected false
        NaturalNumber n = new NaturalNumber2(500);
        NaturalNumber nExpected = new NaturalNumber2(500);
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Test of IsgenerateNextLikelyPrime
     */

    @Test
    public void testIsgenerateNextLikelyPrime_600() {
        // Test case to verify the behavior of IsgenerateNextLikelyPrime with 600
        // The expected is 601
        NaturalNumber n = new NaturalNumber2(600);
        NaturalNumber nExpected = new NaturalNumber2(601);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }

    @Test
    public void testIsgenerateNextLikelyPrime_100000() {
        //challenging
        // Test case to verify the behavior of IsgenerateNextLikelyPrime with 100000
        // The expected is 100003
        NaturalNumber n = new NaturalNumber2(100000);
        NaturalNumber nExpected = new NaturalNumber2(100003);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }

    @Test
    public void testIsgenerateNextLikelyPrime_699() {
        // Test case to verify the behavior of IsgenerateNextLikelyPrime with 699
        // The expected is 701
        NaturalNumber n = new NaturalNumber2(699);
        NaturalNumber nExpected = new NaturalNumber2(701);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }

    @Test
    public void testIsgenerateNextLikelyPrime_4() {
        // Test case to verify the behavior of IsgenerateNextLikelyPrime with 4
        // The expected is 5
        NaturalNumber n = new NaturalNumber2(4);
        NaturalNumber nExpected = new NaturalNumber2(5);
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }
}