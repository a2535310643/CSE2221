import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.random.Random;
import components.random.Random1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Utilities that could be used with RSA cryptosystems.
 *
 * @author Xinwei Zhang
 *
 */
public final class CryptoUtilities {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private CryptoUtilities() {
    }

    /**
     * Useful constant, not a magic number: 3.
     */
    private static final int THREE = 3;

    /**
     * Pseudo-random number generator.
     */
    private static final Random GENERATOR = new Random1L();

    /**
     * Returns a random number uniformly distributed in the interval [0, n].
     *
     * @param n
     *            top end of interval
     * @return random number in interval
     * @requires n > 0
     * @ensures <pre>
     * randomNumber = [a random number uniformly distributed in [0, n]]
     * </pre>
     */
    public static NaturalNumber randomNumber(NaturalNumber n) {
        assert !n.isZero() : "Violation of: n > 0";
        final int base = 10;
        NaturalNumber result;
        int d = n.divideBy10();
        if (n.isZero()) {
            /*
             * Incoming n has only one digit and it is d, so generate a random
             * number uniformly distributed in [0, d]
             */
            int x = (int) ((d + 1) * GENERATOR.nextDouble());
            result = new NaturalNumber2(x);
            n.multiplyBy10(d);
        } else {
            /*
             * Incoming n has more than one digit, so generate a random number
             * (NaturalNumber) uniformly distributed in [0, n], and another
             * (int) uniformly distributed in [0, 9] (i.e., a random digit)
             */
            result = randomNumber(n);
            int lastDigit = (int) (base * GENERATOR.nextDouble());
            result.multiplyBy10(lastDigit);
            n.multiplyBy10(d);
            if (result.compareTo(n) > 0) {
                /*
                 * In this case, we need to try again because generated number
                 * is greater than n; the recursive call's argument is not
                 * "smaller" than the incoming value of n, but this recursive
                 * call has no more than a 90% chance of being made (and for
                 * large n, far less than that), so the probability of
                 * termination is 1
                 */
                result = randomNumber(n);
            }
        }
        return result;
    }

    /**
     * Finds the greatest common divisor of n and m.
     *
     * @param n
     *            one number
     * @param m
     *            the other number
     * @updates n
     * @clears m
     * @ensures n = [greatest common divisor of #n and #m]
     */
    public static void reduceToGCD(NaturalNumber n, NaturalNumber m) {

        /*
         * Use Euclid's algorithm; in pseudocode: if m = 0 then GCD(n, m) = n
         * else GCD(n, m) = GCD(m, n mod m)
         */

        // Check if 'm' is not zero and 'n' is not equal to 'm'
        if (!m.isZero() && !(n.compareTo(m) == 0)) {
            // Calculate the division of 'n' by 'm' to get 'temp'
            NaturalNumber temp = n.divide(m);

            // Recursively call reduceToGCD with 'm' and 'temp' to compute the GCD
            reduceToGCD(m, temp);

            // Copy the value of 'm' to 'n' to update 'n' for the next iteration
            n.copyFrom(m);
        }

        // Clear 'm' to maintain consistent state
        m.clear();

    }

    /**
     * Reports whether n is even.
     *
     * @param n
     *            the number to be checked
     * @return true iff n is even
     * @ensures isEven = (n mod 2 = 0)
     */
    public static boolean isEven(NaturalNumber n) {

        boolean isEven = false;

        // Divide 'n' by 10 and store the last digit in 'last'
        int last = n.divideBy10();

        // Check if the last digit 'last' is even
        isEven = (last % 2 == 0);

        // Multiply 'n' by 10 to restore its original value
        n.multiplyBy10(last);

        // Return the result indicating whether the last digit is even
        return isEven;
        /*
         * This line added just to make the program compilable. Should be
         * replaced with appropriate return statement.
         */
    }

    /**
     * Updates n to its p-th power modulo m.
     *
     * @param n
     *            number to be raised to a power
     * @param p
     *            the power
     * @param m
     *            the modulus
     * @updates n
     * @requires m > 1
     * @ensures n = #n ^ (p) mod m
     */
    public static void powerMod(NaturalNumber n, NaturalNumber p,
            NaturalNumber m) {
        assert m.compareTo(new NaturalNumber2(1)) > 0 : "Violation of: m > 1";

        /*
         * Use the fast-powering algorithm as previously discussed in class,
         * with the additional feature that every multiplication is followed
         * immediately by "reducing the result modulo m"
         */
        NaturalNumber one = new NaturalNumber2(1);
        NaturalNumber two = new NaturalNumber2(2);
        if (p.isZero()) {
            // If the exponent 'p' is zero, set 'n' to 1 (n^0 % m = 1 % m)
            n.setFromInt(1);
        } else {
            if (isEven(p)) {
                // If 'p' is even, divide 'p' by 2 and recursively compute powerMod
                p.divide(two);
                powerMod(n, p, m);

                // Compute 'temp' as a copy of 'n' and multiply 'n' by 'temp'
                NaturalNumber temp = new NaturalNumber2();
                temp.copyFrom(n);
                n.multiply(temp);

                // Restore 'p' by multiplying by 2
                p.multiply(two);
            } else {
                // If 'p' is odd, divide 'p' by 2 and recursively compute powerMod
                p.divide(two);

                // Create a copy of 'n' to calculate the modular exponentiation
                NaturalNumber copy = new NaturalNumber2();
                copy.copyFrom(n);
                powerMod(n, p, m);

                /*
                 * Create 'temp' to store a copy of 'n', and 'mod_temp' for
                 * 'copy' divided by 'm'
                 */
                NaturalNumber temp = new NaturalNumber2();
                NaturalNumber modtemp = new NaturalNumber2();
                modtemp = copy.divide(m);
                temp.copyFrom(n);

                // Multiply 'n' by 'temp' and 'mod_temp' to compute the final result
                n.multiply(temp);
                n.multiply(modtemp);

                // Restore 'p' by multiplying by 2 and adding 1
                p.multiply(two);
                p.add(one);
            }

            // Calculate 'mod' as the result of 'n' divided by 'm' and set 'n' to 'mod'
            NaturalNumber mod = new NaturalNumber2();
            mod = n.divide(m);
            n.copyFrom(mod);
        }
    }

    /**
     * Reports whether w is a "witness" that n is composite, in the sense that
     * either it is a square root of 1 (mod n), or it fails to satisfy the
     * criterion for primality from Fermat's theorem.
     *
     * @param w
     *            witness candidate
     * @param n
     *            number being checked
     * @return true iff w is a "witness" that n is composite
     * @requires n > 2 and 1 < w < n - 1
     * @ensures <pre>
     * isWitnessToCompositeness =
     *     (w ^ 2 mod n = 1)  or  (w ^ (n-1) mod n /= 1)
     * </pre>
     */
    public static boolean isWitnessToCompositeness(NaturalNumber w,
            NaturalNumber n) {
        assert n.compareTo(new NaturalNumber2(2)) > 0 : "Violation of: n > 2";
        assert (new NaturalNumber2(1)).compareTo(w) < 0 : "Violation of: 1 < w";
        n.decrement();
        assert w.compareTo(n) < 0 : "Violation of: w < n - 1";
        n.increment();
        boolean isWitness = false;
        NaturalNumber one = new NaturalNumber2(1);
        NaturalNumber temp = new NaturalNumber2();
        NaturalNumber temp2 = new NaturalNumber2();
        NaturalNumber p = new NaturalNumber2();
        // Copy 'n' to 'p' and decrement 'p'
        p.copyFrom(n);
        p.decrement();

        // Make a copy of 'w' in 'temp' and 'temp2'
        temp.copyFrom(w);
        temp2.copyFrom(w);

        // Calculate 'temp2' as 'w^2' and 'temp' as 'w^2/w'
        temp2.multiply(w);
        temp.copyFrom(temp2);
        temp2.divide(w);

        // Compute 'w^(p mod n)' using the powerMod function
        powerMod(temp2, p, n);

        /*
         * Check if '(w^(p mod n)) mod n' is equal to 1 and 'w^(p mod n)' is not
         * equal to 1
         */
        if (temp.divide(n).compareTo(one) == 0 || temp2.compareTo(one) != 0) {
            isWitness = true;
        }

        // The result indicating whether 'w' is a witness to 'n''s compositeness
        return isWitness;
    }

    /**
     * Reports whether n is a prime; may be wrong with "low" probability.
     *
     * @param n
     *            number to be checked
     * @return true means n is very likely prime; false means n is definitely
     *         composite
     * @requires n > 1
     * @ensures <pre>
     * isPrime1 = [n is a prime number, with small probability of error
     *         if it is reported to be prime, and no chance of error if it is
     *         reported to be composite]
     * </pre>
     */
    public static boolean isPrime1(NaturalNumber n) {
        assert n.compareTo(new NaturalNumber2(1)) > 0 : "Violation of: n > 1";
        boolean isPrime;
        if (n.compareTo(new NaturalNumber2(THREE)) <= 0) {
            /*
             * 2 and 3 are primes
             */
            isPrime = true;
        } else if (isEven(n)) {
            /*
             * evens are composite
             */
            isPrime = false;
        } else {
            /*
             * odd n >= 5: simply check whether 2 is a witness that n is
             * composite (which works surprisingly well :-)
             */
            isPrime = !isWitnessToCompositeness(new NaturalNumber2(2), n);
        }
        return isPrime;
    }

    /**
     * Reports whether n is a prime; may be wrong with "low" probability.
     *
     * @param n
     *            number to be checked
     * @return true means n is very likely prime; false means n is definitely
     *         composite
     * @requires n > 1
     * @ensures <pre>
     * isPrime2 = [n is a prime number, with small probability of error
     *         if it is reported to be prime, and no chance of error if it is
     *         reported to be composite]
     * </pre>
     */
    public static boolean isPrime2(NaturalNumber n) {
        assert n.compareTo(new NaturalNumber2(1)) > 0 : "Violation of: n > 1";

        /*
         * Use the ability to generate random numbers (provided by the
         * randomNumber method above) to generate several witness candidates --
         * say, 10 to 50 candidates -- guessing that n is prime only if none of
         * these candidates is a witness to n being composite (based on fact #3
         * as described in the project description); use the code for isPrime1
         * as a guide for how to do this, and pay attention to the requires
         * clause of isWitnessToCompositeness
         */

        boolean isPrime = true; // Assume 'n' is prime by default
        int k = 0;
        NaturalNumber two = new NaturalNumber2(2);
        NaturalNumber three = new NaturalNumber2(3);

        if (n.compareTo(three) <= 0) {
            // If 'n' is less than or equal to 3, it is prime (2 and 3 are prime)
            isPrime = true;
        } else if (isEven(n)) {
            // If 'n' is even and greater than 2, it cannot be prime
            isPrime = false;
        } else {
            // If 'n' is greater than 3 and odd, perform probabilistic primality testing

            NaturalNumber[] list = new NaturalNumber2[30];
            NaturalNumber temp = new NaturalNumber2();
            temp.copyFrom(n);
            temp.subtract(two);

            // Generate 30 random numbers as potential witnesses to compositeness
            for (int i = 0; i < list.length; i++) {
                list[i] = randomNumber(temp);

                // Ensure that the generated number is greater than 2
                while (list[i].compareTo(two) <= 0) {
                    list[i] = randomNumber(temp);
                }
            }

            // Test the primality using witness numbers
            while (isPrime && k < list.length) {
                if (isWitnessToCompositeness(list[k], n)) {
                    // If any of the witnesses indicates compositeness, 'n' is not prime
                    isPrime = false;
                }
                k++;
            }
        }

        // The result indicating whether 'n' is prime or not
        return isPrime;
        /*
         * This line added just to make the program compilable. Should be
         * replaced with appropriate return statement.
         */
    }

    /**
     * Generates a likely prime number at least as large as some given number.
     *
     * @param n
     *            minimum value of likely prime
     * @updates n
     * @requires n > 1
     * @ensures n >= #n and [n is very likely a prime number]
     */
    public static void generateNextLikelyPrime(NaturalNumber n) {
        assert n.compareTo(new NaturalNumber2(1)) > 0 : "Violation of: n > 1";

        /*
         * Use isPrime2 to check numbers, starting at n and increasing through
         * the odd numbers only (why?), until n is likely prime
         */
        NaturalNumber two = new NaturalNumber2(2);
        boolean isprime = false;
        NaturalNumber nextprime = new NaturalNumber2();
        nextprime.copyFrom(n);

        // If 'nextprime' is even, increment it to the next odd number
        if (isEven(nextprime)) {
            nextprime.increment();
        }

        /*
         * Check if 'nextprime' is a prime number, and if not, increment it by 2
         * and re-check
         */
        isprime = isPrime2(nextprime);
        while (!isprime) {
            nextprime.add(two);
            isprime = isPrime2(nextprime);
        }

        // Update 'n' with the next prime number found
        n.copyFrom(nextprime);

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Sanity check of randomNumber method -- just so everyone can see how
         * it might be "tested"
         */
        final int testValue = 17;
        final int testSamples = 100000;
        NaturalNumber test = new NaturalNumber2(testValue);
        int[] count = new int[testValue + 1];
        for (int i = 0; i < count.length; i++) {
            count[i] = 0;
        }
        for (int i = 0; i < testSamples; i++) {
            NaturalNumber rn = randomNumber(test);
            assert rn.compareTo(test) <= 0 : "Help!";
            count[rn.toInt()]++;
        }
        for (int i = 0; i < count.length; i++) {
            out.println("count[" + i + "] = " + count[i]);
        }
        out.println("  expected value = "
                + (double) testSamples / (double) (testValue + 1));

        /*
         * Check user-supplied numbers for primality, and if a number is not
         * prime, find the next likely prime after it
         */
        while (true) {
            out.print("n = ");
            NaturalNumber n = new NaturalNumber2(in.nextLine());
            if (n.compareTo(new NaturalNumber2(2)) < 0) {
                out.println("Bye!");
                break;
            } else {
                if (isPrime1(n)) {
                    out.println(n + " is probably a prime number"
                            + " according to isPrime1.");
                } else {
                    out.println(n + " is a composite number"
                            + " according to isPrime1.");
                }
                if (isPrime2(n)) {
                    out.println(n + " is probably a prime number"
                            + " according to isPrime2.");
                } else {
                    out.println(n + " is a composite number"
                            + " according to isPrime2.");
                    generateNextLikelyPrime(n);
                    out.println("  next likely prime is " + n);
                }
            }
        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}