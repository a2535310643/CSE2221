import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;

public class GlossaryTest {

    //Boundary
    @Test
    public void checkSingleWordTest1() {
        boolean a = Glossary.checkSingleWord(" ");
        assertEquals(false, a);
    }

    //Routine
    @Test
    public void checkSingleWordTest2() {
        boolean a = Glossary.checkSingleWord("a");
        assertEquals(true, a);
    }

    //Routine
    @Test
    public void checkSingleWordTest3() {
        boolean a = Glossary.checkSingleWord("word");
        assertEquals(true, a);
    }

    //Challenging
    @Test
    public void checkSingleWordTest4() {
        boolean a = Glossary.checkSingleWord("It is a");
        assertEquals(false, a);
    }

    //Challenging
    @Test
    public void checkSingleWordTest5() {
        boolean a = Glossary.checkSingleWord("               ");
        assertEquals(false, a);
    }

    //Boundary
    @Test
    public void checkSentenceTest1() {
        boolean a = Glossary.checkSentence("a");
        assertEquals(false, a);
    }

    //Challenging
    @Test
    public void checkSentenceTest2() {
        boolean a = Glossary.checkSentence("         ");
        assertEquals(false, a);
    }

    //routine
    @Test
    public void checkSentenceTest3() {
        boolean a = Glossary.checkSentence("This is a test");
        assertEquals(true, a);
    }

    //routine
    @Test
    public void checkSentenceTest4() {
        boolean a = Glossary.checkSentence("Thisisisisisiisi a test");
        assertEquals(true, a);
    }

    //Challenging
    @Test
    public void checkSentenceTest5() {
        boolean a = Glossary.checkSentence("y o u");
        assertEquals(true, a);
    }

    //routine
    @Test
    public void saveWordMeaningTest1() {

        SimpleReader fileReader = new SimpleReader1L("test\\test1.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        boolean a = map.hasKey("word");
        boolean b = map.hasKey("definition");
        boolean c = map.hasKey("book");
        boolean d = map.hasKey("term");
        String e = map.value("definition");
        String f = map.value("book");
        String g = map.value("term");
        assertEquals(false, a);
        assertEquals(true, b);
        assertEquals(true, c);
        assertEquals(true, d);
        assertEquals("a sequence of words that gives meaning to a term", e);
        assertEquals("a printed or written literary work", f);
        assertEquals("a word whose definition is in a glossary", g);

    }

    //routine
    @Test
    public void saveWordMeaningTest2() {

        SimpleReader fileReader = new SimpleReader1L("test\\test2.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        boolean a = map.hasKey("word");
        boolean b = map.hasKey("meaning");
        boolean c = map.hasKey("glossary");
        boolean d = map.hasKey("language");
        String e = map.value("meaning");
        String f = map.value("word");
        String g = map.value("glossary");
        String n = map.value("language");
        assertEquals(true, a);
        assertEquals(true, b);
        assertEquals(true, c);
        assertEquals(true, d);
        assertEquals(
                "something that one wishes to convey, especially by language",
                e);
        assertEquals(
                "a string of characters in a language, which has at least one character",
                f);
        assertEquals(
                "a list of difficult or specialized terms, with their definitions,usually near the end of a book",
                g);
        assertEquals(
                "a set of strings of characters, each of which has meaning", n);

    }

    //routine
    @Test
    public void FindAnotherWordsInSentenceTest1() {
        Set<String> item = new Set1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test3.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        item = Glossary.FindAnotherWordsInSentence(
                "a word whose definition is in a glossary", map);
        assertEquals(true, item.contains("word"));

    }

    //challenging && Boundary
    @Test
    public void FindAnotherWordsInSentenceTest2() {
        Set<String> item = new Set1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test3.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        item = Glossary.FindAnotherWordsInSentence(
                "a words whose definition is in a glossary", map);
        assertEquals(false, item.contains("word"));

    }

    //challenging
    @Test
    public void FindAnotherWordsInSentenceTest3() {
        Set<String> item = new Set1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test3.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        item = Glossary.FindAnotherWordsInSentence(
                "a words whose definition is in a book", map);
        assertEquals(false, item.contains("word"));
        assertEquals(true, item.contains("book"));

    }

    //challenging
    @Test
    public void FindAnotherWordsInSentenceTest4() {
        Set<String> item = new Set1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test3.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        item = Glossary.FindAnotherWordsInSentence(
                "a word whose definition is in a book", map);
        assertEquals(true, item.contains("word"));
        assertEquals(true, item.contains("book"));

    }

    //challenging
    @Test
    public void FindAnotherWordsInSentenceTest5() {
        Set<String> item = new Set1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test3.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        item = Glossary.FindAnotherWordsInSentence(
                "a word whose definition is in a book", map);
        assertEquals(false, item.contains("you"));
    }

    //routine
    @Test
    public void MapToSortedQueueTest1() {
        Queue<String> words = new Queue1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test4.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        words = Glossary.MapToSortedQueue(map);
        int count = 1;
        int right = 0;
        for (String a : words) {
            if (count == 1) {
                if (a.equals("glossary")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
            if (count == 2) {
                if (a.equals("language")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
            if (count == 3) {
                if (a.equals("meaning")) {
                    right += 1;
                    count += 1;
                }
            }
            if (count == 4) {
                if (a.equals("word")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
        }
        assertEquals(4, right);

    }

    //challenging&&boundary
    @Test
    public void MapToSortedQueueTest2() {
        Queue<String> words = new Queue1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test5.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        words = Glossary.MapToSortedQueue(map);
        int count = 1;
        int right = 0;
        for (String a : words) {
            if (count == 1) {
                if (a.equals("apple")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
            if (count == 2) {
                if (a.equals("man")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
            if (count == 3) {
                if (a.equals("meaning")) {
                    ;
                    right += 1;
                    count += 1;
                }
            }
        }
        assertEquals(3, right);

    }

    //challenging&&boundary
    @Test
    public void MapToSortedQueueTest3() {
        Queue<String> words = new Queue1L<String>();
        SimpleReader fileReader = new SimpleReader1L("test\\test6.txt");
        Map<String, String> map = new Map1L<String, String>();
        Glossary.saveWordMeaning(fileReader, map);
        words = Glossary.MapToSortedQueue(map);
        int count = 1;
        int right = 0;
        for (String a : words) {
            if (count == 1) {
                if (a.equals("apple")) {

                    right += 1;
                    count += 1;
                }
            }
            if (count == 2) {
                if (a.equals("man")) {

                    right += 1;
                    count += 1;
                }
            }
            if (count == 3) {
                if (a.equals("meaning")) {

                    right += 1;
                    count += 1;
                }
            }
            if (count == 4) {
                if (a.equals("men")) {

                    right += 1;
                    count += 1;
                }
            }
        }
        assertEquals(4, right);

    }

}
