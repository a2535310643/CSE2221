import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 *
 *
 * @author Xinwei Zhang
 *
 *
 */

public final class Glossary {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Glossary() {
        // no code needed here
    }

    /**
     * check if {@code str} is a single word.
     *
     * @param str
     *            given string
     * @return if {@code str} is a single word
     *
     */
    public static boolean checkSingleWord(String str) {
        // Initialize a flag to assume the string is a single word
        boolean single = true;
        // Initialize a flag to control the loop
        boolean a = true;
        // Check if the input string is empty
        if (str.length() < 1) {
            single = false;
        } else {
            // Iterate through the characters of the string
            for (int i = 0; i < str.length() && a; i++) {
                // If a space is encountered, set the flag to false and exit the loop
                if (str.charAt(i) == ' ') {
                    single = false;
                    a = false;
                }
            }
        }
        // Return the result, indicating whether the input string is a single word
        return single;
    }

    /**
     * check if {@code str} is a sentence.
     *
     * @param str
     *            given string
     * @return if {@code str} is a sentence
     *
     */
    public static boolean checkSentence(String str) {
        // Initialize a flag to assume the input string is not a sentence
        boolean sentence = false;
        // Initialize a flag to control the loop
        boolean a = true;
        // Check if the input string is empty
        if (str.length() < 1) {
            sentence = false;
        } else {
            for (int i = 0; i < str.length() && a; i++) {
                // If a space is encountered and the first character is not a space, consider it a sentence
                if (str.charAt(i) == ' ' && str.charAt(0) != ' ') {
                    sentence = true;
                    a = false;
                }
            }
        }
        // Return the result, indicating whether the input string appears to be a sentence
        return sentence;
    }

    public static void saveWordMeaning(SimpleReader in,
            Map<String, String> match) {
        String word = "";
        String meaning = "";
        // Loop until the end of the input is reached
        while (!in.atEOS()) {
            String temp = in.nextLine();
            // Check if the current line contains a single word
            if (checkSingleWord(temp)) {
                word = temp;
                // Check if the current line appears to be a sentence
            } else if (checkSentence(temp)) {
                meaning += temp;
                // If neither a single word nor a sentence is detected, add the word-meaning pair to the map
            } else {
                match.add(word, meaning);
                word = ""; // Reset the current word
                meaning = ""; // Reset the current meaning
            }
        }
        // If there's a pending word-meaning pair, add it to the map
        if (word.length() > 0 && meaning.length() > 0) {
            match.add(word, meaning);
        }

    }

    /**
     * Read lines from given file and save the word and matched meaning into a
     * maps {@code key} as word, {@code value} as meaning.
     *
     * @param in
     *            the input file reader
     * @param match
     *            the output map that saves term and definition pairs
     * @update match
     */

    /**
     * Find another words that exist in this word's meaning {@code key} as word,
     * {@code value} as meaning.
     *
     * @param str
     *            the meanings of the word
     * @param match
     *            the map with all words and matched meanings
     * @update match
     */

    public static Set<String> FindAnotherWordsInSentence(String str,
            Map<String, String> match) {
        Set<String> item = new Set1L<String>();
        String s[] = str.split(" ");
        // Iterate through the word-meaning pairs in the map
        for (Map.Pair<String, String> word : match) {
            for (String n : s) {
                // Check if the current word from the sentence matches a key in the map
                if (n.equals(word.key()) && !item.contains(word.key())) {
                    item.add(word.key());
                }
            }

        }
        return item; // Return the Set of matching words
    }

    /**
     * Get the word from the Map and save them into a Queue with sorted form.
     *
     * @param match
     *            the given Map that stores all words and meanings
     * @return A sorted Queue<String> that stores all words
     */
    public static Queue<String> MapToSortedQueue(Map<String, String> match) {
        Queue<String> words = new Queue1L<String>();
        // Iterate through the word-meaning pairs in the map
        for (Map.Pair<String, String> item : match) {

            words.enqueue(item.key());
        }
        // Create a comparator for lexicographic sorting
        Comparator<String> strCompare = new abcd();
        // Sort the Queue in lexicographic order
        words.sort(strCompare);
        // Return the sorted Queue of words
        return words;
    }

    /**
     * prints index.html
     *
     * @param words
     *            all words that need to be printed with hyperlink
     * @param filePath
     *            where to generate file
     */
    public static void printtoplevelindexIndex(Queue<String> words,
            String filePath) {
        // Create a SimpleWriter to write the index.html file
        SimpleWriter index = new SimpleWriter1L(filePath + "/" + "index.html");
        // Write the HTML structure for the index page
        index.print("<html>\n<head>\n<title>Glossary</title>\n</head>\n");
        index.print(
                "<body>\n<h2>Glossary</h2>\n<hr />\n<h3>Index</h3>\n<ul>\n");
        // Iterate through the words in the Queue and generate links in the index
        for (String item : words) {
            index.println(
                    "<li><a href=\"" + item + ".html\">" + item + "</a></li>");
        }
        // Close the HTML structure
        index.print("</ul>\n</body>\n</html>\n");
        index.close();
    }

    /**
     * create words definition html file
     *
     * @param match
     *            a Map<String, String> that stores all words with meanings
     * @param filePath
     *            where to generate files
     */
    public static void printTerms(Map<String, String> match, String filePath) {
        Set<String> item = new Set1L<String>();
        // Iterate through the word-meaning pairs in the map
        for (Map.Pair<String, String> word : match) {
            SimpleWriter out = new SimpleWriter1L(
                    filePath + "/" + word.key() + ".html");
            // Write the HTML structure for the term's page
            out.print("<html>\n<head>\n<title>" + word.key()
                    + "</title>\n</head>\n");
            out.print("<body>\n<h2><b><i><font color=\"red\">" + word.key()
                    + "</font></i></b></h2>\n");
            String meaning = word.value();
            item = FindAnotherWordsInSentence(word.value(), match);
            String meanSen = "";
            if (item.size() != 0) {
                for (String another : item) {
                    // Replace related terms with links to their respective pages
                    meanSen = meaning.substring(0, meaning.indexOf(another))
                            + "<a href=\"" + another + ".html\">" + another
                            + "</a>"
                            + meaning.substring(meaning.indexOf(another)
                                    + another.length());
                }
            } else {
                meanSen = meaning;
            }
            // Write the term's definition
            out.print("<blockquote>" + meanSen + "</blockquote>");
            out.println("<hr />");
            // Add a link back to the index page
            out.println("<p>Return to <a href=\"index.html\">index</a>.</p>");
            out.print("</body>\n</html>");
            // Close the SimpleWriter for the current term's HTML file
            out.close();
        }
    }

    private static class abcd implements Comparator<String> {

        /**
         * compares which String is bigger.
         *
         * @param str1
         *            the first String
         * @param str2
         *            the second String
         * @return 1 if {@code str1} is larger than {@code str2} -1 if
         *         {@code str1} is larger than {@code str2} 0 if @code str1}
         *         equals to {@code str2}
         */
        @Override
        public int compare(String str1, String str2) {
            if (str1.compareTo(str2) > 0) {
                return 1;
            } else if (str1.compareTo(str2) < 0) {
                return -1;
            } else {
                return 0;
            }
        }

        /**
         * Main method.
         *
         * @param args
         *            the command line arguments; unused here
         */
        public static void main(String[] args) {
            SimpleReader in = new SimpleReader1L();
            SimpleWriter out = new SimpleWriter1L();
            Map<String, String> dictionary = new Map1L<String, String>();

            out.print("Please enter your txt file:");
            String fileName = in.nextLine();
            out.print("Please enter your folder:");
            String filePath = in.nextLine();
            SimpleReader fileReader = new SimpleReader1L(fileName);
            saveWordMeaning(fileReader, dictionary);
            Queue<String> mapqueue = MapToSortedQueue(dictionary);
            printtoplevelindexIndex(mapqueue, filePath);
            printTerms(dictionary, filePath);

            in.close();
            out.close();
        }
    }
}