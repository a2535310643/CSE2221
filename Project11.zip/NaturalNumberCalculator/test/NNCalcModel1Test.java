import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

public class NNCalcModel1Test {

    @Test
    public void toptest() {
        NNCalcModel n = new NNCalcModel1();
        NaturalNumber a = new NaturalNumber2();
        NaturalNumber b = new NaturalNumber2();
        a = n.top();
        assertEquals(a, b);

    }

    @Test
    public void bottomtest() {
        NNCalcModel n = new NNCalcModel1();
        NaturalNumber a = new NaturalNumber2();
        NaturalNumber b = new NaturalNumber2();
        a = n.bottom();
        assertEquals(a, b);

    }
}
