import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

public class ABCDGuesser1 {

    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        double b = -1;
        while (b <= 0) {
            out.println("Enter a positive number for w/x/y/z: ");
            String a = in.nextLine();
            if (FormatChecker.canParseInt(a)) {
                b = Integer.parseInt(a);
            } else {
                b = -1;
            }
        }
        return b;
    }

    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        double b = -1;
        double c = 1;
        while (c == 1) {
            out.println("Enter a positive number and not equal to 1 for u: ");
            String a = in.nextLine();
            if (FormatChecker.canParseDouble(a)) {
                b = Double.parseDouble(a);
                if (b > 0) {
                    c = b;
                }
            } else {
                b = -1;
            }
        }
        return c;
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        double u = getPositiveDoubleNotOne(in, out);

        double w = getPositiveDouble(in, out);

        double x = getPositiveDouble(in, out);

        double y = getPositiveDouble(in, out);

        double z = getPositiveDouble(in, out);
        double resulst_a = 0;
        double resulst_b = 0;
        double resulst_c = 0;
        double resulst_d = 0;
        double[] arr = { -5, -4, -3, -2, -1, -1.0 / 2.0, -1.0 / 3.0, -1.0 / 4.0,
                0, 1.0 / 2.0, 1.0 / 3.0, 1.0 / 4.0, 1, 2, 3, 4, 5 };
        double[] result;
        int l = arr.length;
        int wi = 0;
        int xi = 0;
        int yi = 0;
        int zi = 0;
        double error = 0.01;
        while (wi < l) {
            double a = arr[wi];
            xi = 0;
            while (xi < l) {
                double b = arr[xi];
                yi = 0;
                while (yi < l) {
                    double c = arr[yi];
                    zi = 0;
                    while (zi < l) {
                        double d = arr[zi];

                        double approximation = Math.pow(w, a) * Math.pow(x, b)
                                * Math.pow(y, c) * Math.pow(z, d);
                        double relativeError = Math.abs(approximation - u) / u;
                        if (relativeError < error) {
                            error = relativeError;
                            resulst_a = a;
                            resulst_b = b;
                            resulst_c = c;
                            resulst_d = d;
                        }
                        zi = zi + 1;
                    }
                    yi = yi + 1;
                }
                xi = xi + 1;

            }
            wi = wi + 1;
        }

        out.println("This is: " + resulst_a + " " + resulst_b + " " + resulst_c
                + " " + resulst_d);

        in.close();
        out.close();
    }

}
